// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xftran_u_hw.h"

extern XFtran_u_hw_Config XFtran_u_hw_ConfigTable[];

#ifdef SDT
XFtran_u_hw_Config *XFtran_u_hw_LookupConfig(UINTPTR BaseAddress) {
	XFtran_u_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XFtran_u_hw_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XFtran_u_hw_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XFtran_u_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFtran_u_hw_Initialize(XFtran_u_hw *InstancePtr, UINTPTR BaseAddress) {
	XFtran_u_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFtran_u_hw_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFtran_u_hw_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XFtran_u_hw_Config *XFtran_u_hw_LookupConfig(u16 DeviceId) {
	XFtran_u_hw_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XFTRAN_U_HW_NUM_INSTANCES; Index++) {
		if (XFtran_u_hw_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XFtran_u_hw_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XFtran_u_hw_Initialize(XFtran_u_hw *InstancePtr, u16 DeviceId) {
	XFtran_u_hw_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XFtran_u_hw_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XFtran_u_hw_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

