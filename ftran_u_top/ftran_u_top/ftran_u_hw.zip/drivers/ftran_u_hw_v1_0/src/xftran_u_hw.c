// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xftran_u_hw.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XFtran_u_hw_CfgInitialize(XFtran_u_hw *InstancePtr, XFtran_u_hw_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XFtran_u_hw_Start(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL) & 0x80;
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XFtran_u_hw_IsDone(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XFtran_u_hw_IsIdle(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XFtran_u_hw_IsReady(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XFtran_u_hw_EnableAutoRestart(XFtran_u_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XFtran_u_hw_DisableAutoRestart(XFtran_u_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XFtran_u_hw_Get_return(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XFtran_u_hw_Set_mode(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_MODE_DATA, Data);
}

u32 XFtran_u_hw_Get_mode(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_MODE_DATA);
    return Data;
}

void XFtran_u_hw_Set_u_start(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_START_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_START_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_u_start(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_START_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_START_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_u_end(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_END_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_END_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_u_end(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_END_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_END_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_u_index(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_INDEX_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_INDEX_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_u_index(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_INDEX_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_INDEX_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_u_value(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_VALUE_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_VALUE_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_u_value(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_VALUE_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_VALUE_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_u_pivot_index(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_PIVOT_INDEX_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_PIVOT_INDEX_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_u_pivot_index(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_PIVOT_INDEX_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_U_PIVOT_INDEX_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_column_count(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_COLUMN_COUNT_DATA, Data);
}

u32 XFtran_u_hw_Get_column_count(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_COLUMN_COUNT_DATA);
    return Data;
}

void XFtran_u_hw_Set_entry_count(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_ENTRY_COUNT_DATA, Data);
}

u32 XFtran_u_hw_Get_entry_count(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_ENTRY_COUNT_DATA);
    return Data;
}

void XFtran_u_hw_Set_block_pivot_value(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_PIVOT_VALUE_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_PIVOT_VALUE_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_block_pivot_value(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_PIVOT_VALUE_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_PIVOT_VALUE_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_block_start(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_START_DATA, Data);
}

u32 XFtran_u_hw_Get_block_start(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_START_DATA);
    return Data;
}

void XFtran_u_hw_Set_block_size(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SIZE_DATA, Data);
}

u32 XFtran_u_hw_Get_block_size(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SIZE_DATA);
    return Data;
}

void XFtran_u_hw_Set_rhs_array(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_ARRAY_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_ARRAY_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_rhs_array(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_ARRAY_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_ARRAY_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_rhs_index(XFtran_u_hw *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_INDEX_DATA, (u32)(Data));
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_INDEX_DATA + 4, (u32)(Data >> 32));
}

u64 XFtran_u_hw_Get_rhs_index(XFtran_u_hw *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_INDEX_DATA);
    Data += (u64)XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_INDEX_DATA + 4) << 32;
    return Data;
}

void XFtran_u_hw_Set_rhs_size(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_SIZE_DATA, Data);
}

u32 XFtran_u_hw_Get_rhs_size(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_SIZE_DATA);
    return Data;
}

void XFtran_u_hw_Set_rhs_count(XFtran_u_hw *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_DATA, Data);
}

u32 XFtran_u_hw_Get_rhs_count(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_DATA);
    return Data;
}

u32 XFtran_u_hw_Get_rhs_count_out(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_OUT_DATA);
    return Data;
}

u32 XFtran_u_hw_Get_rhs_count_out_vld(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_OUT_CTRL);
    return Data & 0x1;
}

u32 XFtran_u_hw_Get_block_synthetic_ticks(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SYNTHETIC_TICKS_DATA);
    return Data;
}

u32 XFtran_u_hw_Get_block_synthetic_ticks_vld(XFtran_u_hw *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SYNTHETIC_TICKS_CTRL);
    return Data & 0x1;
}

void XFtran_u_hw_InterruptGlobalEnable(XFtran_u_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_GIE, 1);
}

void XFtran_u_hw_InterruptGlobalDisable(XFtran_u_hw *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_GIE, 0);
}

void XFtran_u_hw_InterruptEnable(XFtran_u_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_IER);
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_IER, Register | Mask);
}

void XFtran_u_hw_InterruptDisable(XFtran_u_hw *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_IER);
    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_IER, Register & (~Mask));
}

void XFtran_u_hw_InterruptClear(XFtran_u_hw *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XFtran_u_hw_WriteReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_ISR, Mask);
}

u32 XFtran_u_hw_InterruptGetEnabled(XFtran_u_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_IER);
}

u32 XFtran_u_hw_InterruptGetStatus(XFtran_u_hw *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XFtran_u_hw_ReadReg(InstancePtr->Control_BaseAddress, XFTRAN_U_HW_CONTROL_ADDR_ISR);
}

