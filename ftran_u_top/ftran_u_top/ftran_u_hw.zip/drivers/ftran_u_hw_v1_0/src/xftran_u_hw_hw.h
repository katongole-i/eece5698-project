// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of mode
//        bit 31~0 - mode[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of u_start
//        bit 31~0 - u_start[31:0] (Read/Write)
// 0x24 : Data signal of u_start
//        bit 31~0 - u_start[63:32] (Read/Write)
// 0x28 : reserved
// 0x2c : Data signal of u_end
//        bit 31~0 - u_end[31:0] (Read/Write)
// 0x30 : Data signal of u_end
//        bit 31~0 - u_end[63:32] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of u_index
//        bit 31~0 - u_index[31:0] (Read/Write)
// 0x3c : Data signal of u_index
//        bit 31~0 - u_index[63:32] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of u_value
//        bit 31~0 - u_value[31:0] (Read/Write)
// 0x48 : Data signal of u_value
//        bit 31~0 - u_value[63:32] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of u_pivot_index
//        bit 31~0 - u_pivot_index[31:0] (Read/Write)
// 0x54 : Data signal of u_pivot_index
//        bit 31~0 - u_pivot_index[63:32] (Read/Write)
// 0x58 : reserved
// 0x5c : Data signal of column_count
//        bit 31~0 - column_count[31:0] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of entry_count
//        bit 31~0 - entry_count[31:0] (Read/Write)
// 0x68 : reserved
// 0x6c : Data signal of block_pivot_value
//        bit 31~0 - block_pivot_value[31:0] (Read/Write)
// 0x70 : Data signal of block_pivot_value
//        bit 31~0 - block_pivot_value[63:32] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of block_start
//        bit 31~0 - block_start[31:0] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of block_size
//        bit 31~0 - block_size[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of rhs_array
//        bit 31~0 - rhs_array[31:0] (Read/Write)
// 0x8c : Data signal of rhs_array
//        bit 31~0 - rhs_array[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of rhs_index
//        bit 31~0 - rhs_index[31:0] (Read/Write)
// 0x98 : Data signal of rhs_index
//        bit 31~0 - rhs_index[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of rhs_size
//        bit 31~0 - rhs_size[31:0] (Read/Write)
// 0xa4 : reserved
// 0xa8 : Data signal of rhs_count
//        bit 31~0 - rhs_count[31:0] (Read/Write)
// 0xac : reserved
// 0xb0 : Data signal of rhs_count_out
//        bit 31~0 - rhs_count_out[31:0] (Read)
// 0xb4 : Control signal of rhs_count_out
//        bit 0  - rhs_count_out_ap_vld (Read/COR)
//        others - reserved
// 0xc0 : Data signal of block_synthetic_ticks
//        bit 31~0 - block_synthetic_ticks[31:0] (Read)
// 0xc4 : Control signal of block_synthetic_ticks
//        bit 0  - block_synthetic_ticks_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XFTRAN_U_HW_CONTROL_ADDR_AP_CTRL                    0x00
#define XFTRAN_U_HW_CONTROL_ADDR_GIE                        0x04
#define XFTRAN_U_HW_CONTROL_ADDR_IER                        0x08
#define XFTRAN_U_HW_CONTROL_ADDR_ISR                        0x0c
#define XFTRAN_U_HW_CONTROL_ADDR_AP_RETURN                  0x10
#define XFTRAN_U_HW_CONTROL_BITS_AP_RETURN                  32
#define XFTRAN_U_HW_CONTROL_ADDR_MODE_DATA                  0x18
#define XFTRAN_U_HW_CONTROL_BITS_MODE_DATA                  32
#define XFTRAN_U_HW_CONTROL_ADDR_U_START_DATA               0x20
#define XFTRAN_U_HW_CONTROL_BITS_U_START_DATA               64
#define XFTRAN_U_HW_CONTROL_ADDR_U_END_DATA                 0x2c
#define XFTRAN_U_HW_CONTROL_BITS_U_END_DATA                 64
#define XFTRAN_U_HW_CONTROL_ADDR_U_INDEX_DATA               0x38
#define XFTRAN_U_HW_CONTROL_BITS_U_INDEX_DATA               64
#define XFTRAN_U_HW_CONTROL_ADDR_U_VALUE_DATA               0x44
#define XFTRAN_U_HW_CONTROL_BITS_U_VALUE_DATA               64
#define XFTRAN_U_HW_CONTROL_ADDR_U_PIVOT_INDEX_DATA         0x50
#define XFTRAN_U_HW_CONTROL_BITS_U_PIVOT_INDEX_DATA         64
#define XFTRAN_U_HW_CONTROL_ADDR_COLUMN_COUNT_DATA          0x5c
#define XFTRAN_U_HW_CONTROL_BITS_COLUMN_COUNT_DATA          32
#define XFTRAN_U_HW_CONTROL_ADDR_ENTRY_COUNT_DATA           0x64
#define XFTRAN_U_HW_CONTROL_BITS_ENTRY_COUNT_DATA           32
#define XFTRAN_U_HW_CONTROL_ADDR_BLOCK_PIVOT_VALUE_DATA     0x6c
#define XFTRAN_U_HW_CONTROL_BITS_BLOCK_PIVOT_VALUE_DATA     64
#define XFTRAN_U_HW_CONTROL_ADDR_BLOCK_START_DATA           0x78
#define XFTRAN_U_HW_CONTROL_BITS_BLOCK_START_DATA           32
#define XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SIZE_DATA            0x80
#define XFTRAN_U_HW_CONTROL_BITS_BLOCK_SIZE_DATA            32
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_ARRAY_DATA             0x88
#define XFTRAN_U_HW_CONTROL_BITS_RHS_ARRAY_DATA             64
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_INDEX_DATA             0x94
#define XFTRAN_U_HW_CONTROL_BITS_RHS_INDEX_DATA             64
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_SIZE_DATA              0xa0
#define XFTRAN_U_HW_CONTROL_BITS_RHS_SIZE_DATA              32
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_DATA             0xa8
#define XFTRAN_U_HW_CONTROL_BITS_RHS_COUNT_DATA             32
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_OUT_DATA         0xb0
#define XFTRAN_U_HW_CONTROL_BITS_RHS_COUNT_OUT_DATA         32
#define XFTRAN_U_HW_CONTROL_ADDR_RHS_COUNT_OUT_CTRL         0xb4
#define XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SYNTHETIC_TICKS_DATA 0xc0
#define XFTRAN_U_HW_CONTROL_BITS_BLOCK_SYNTHETIC_TICKS_DATA 32
#define XFTRAN_U_HW_CONTROL_ADDR_BLOCK_SYNTHETIC_TICKS_CTRL 0xc4

