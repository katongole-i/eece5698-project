// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.2 (64-bit)
// Tool Version Limit: 2023.10
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module ftran_u_hw_control_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 8,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire                          interrupt,
    output wire                          ap_start,
    input  wire                          ap_done,
    input  wire                          ap_ready,
    input  wire                          ap_idle,
    input  wire [31:0]                   ap_return,
    output wire [31:0]                   mode,
    output wire [63:0]                   u_start,
    output wire [63:0]                   u_end,
    output wire [63:0]                   u_index,
    output wire [63:0]                   u_value,
    output wire [63:0]                   u_pivot_index,
    output wire [31:0]                   column_count,
    output wire [31:0]                   entry_count,
    output wire [63:0]                   block_pivot_value,
    output wire [31:0]                   block_start,
    output wire [31:0]                   block_size,
    output wire [63:0]                   rhs_array,
    output wire [63:0]                   rhs_index,
    output wire [31:0]                   rhs_size,
    output wire [31:0]                   rhs_count,
    input  wire [31:0]                   rhs_count_out,
    input  wire                          rhs_count_out_ap_vld,
    input  wire [31:0]                   block_synthetic_ticks,
    input  wire                          block_synthetic_ticks_ap_vld
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_hs
//
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of ap_return
//        bit 31~0 - ap_return[31:0] (Read)
// 0x18 : Data signal of mode
//        bit 31~0 - mode[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of u_start
//        bit 31~0 - u_start[31:0] (Read/Write)
// 0x24 : Data signal of u_start
//        bit 31~0 - u_start[63:32] (Read/Write)
// 0x28 : reserved
// 0x2c : Data signal of u_end
//        bit 31~0 - u_end[31:0] (Read/Write)
// 0x30 : Data signal of u_end
//        bit 31~0 - u_end[63:32] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of u_index
//        bit 31~0 - u_index[31:0] (Read/Write)
// 0x3c : Data signal of u_index
//        bit 31~0 - u_index[63:32] (Read/Write)
// 0x40 : reserved
// 0x44 : Data signal of u_value
//        bit 31~0 - u_value[31:0] (Read/Write)
// 0x48 : Data signal of u_value
//        bit 31~0 - u_value[63:32] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of u_pivot_index
//        bit 31~0 - u_pivot_index[31:0] (Read/Write)
// 0x54 : Data signal of u_pivot_index
//        bit 31~0 - u_pivot_index[63:32] (Read/Write)
// 0x58 : reserved
// 0x5c : Data signal of column_count
//        bit 31~0 - column_count[31:0] (Read/Write)
// 0x60 : reserved
// 0x64 : Data signal of entry_count
//        bit 31~0 - entry_count[31:0] (Read/Write)
// 0x68 : reserved
// 0x6c : Data signal of block_pivot_value
//        bit 31~0 - block_pivot_value[31:0] (Read/Write)
// 0x70 : Data signal of block_pivot_value
//        bit 31~0 - block_pivot_value[63:32] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of block_start
//        bit 31~0 - block_start[31:0] (Read/Write)
// 0x7c : reserved
// 0x80 : Data signal of block_size
//        bit 31~0 - block_size[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of rhs_array
//        bit 31~0 - rhs_array[31:0] (Read/Write)
// 0x8c : Data signal of rhs_array
//        bit 31~0 - rhs_array[63:32] (Read/Write)
// 0x90 : reserved
// 0x94 : Data signal of rhs_index
//        bit 31~0 - rhs_index[31:0] (Read/Write)
// 0x98 : Data signal of rhs_index
//        bit 31~0 - rhs_index[63:32] (Read/Write)
// 0x9c : reserved
// 0xa0 : Data signal of rhs_size
//        bit 31~0 - rhs_size[31:0] (Read/Write)
// 0xa4 : reserved
// 0xa8 : Data signal of rhs_count
//        bit 31~0 - rhs_count[31:0] (Read/Write)
// 0xac : reserved
// 0xb0 : Data signal of rhs_count_out
//        bit 31~0 - rhs_count_out[31:0] (Read)
// 0xb4 : Control signal of rhs_count_out
//        bit 0  - rhs_count_out_ap_vld (Read/COR)
//        others - reserved
// 0xc0 : Data signal of block_synthetic_ticks
//        bit 31~0 - block_synthetic_ticks[31:0] (Read)
// 0xc4 : Control signal of block_synthetic_ticks
//        bit 0  - block_synthetic_ticks_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_AP_CTRL                      = 8'h00,
    ADDR_GIE                          = 8'h04,
    ADDR_IER                          = 8'h08,
    ADDR_ISR                          = 8'h0c,
    ADDR_AP_RETURN_0                  = 8'h10,
    ADDR_MODE_DATA_0                  = 8'h18,
    ADDR_MODE_CTRL                    = 8'h1c,
    ADDR_U_START_DATA_0               = 8'h20,
    ADDR_U_START_DATA_1               = 8'h24,
    ADDR_U_START_CTRL                 = 8'h28,
    ADDR_U_END_DATA_0                 = 8'h2c,
    ADDR_U_END_DATA_1                 = 8'h30,
    ADDR_U_END_CTRL                   = 8'h34,
    ADDR_U_INDEX_DATA_0               = 8'h38,
    ADDR_U_INDEX_DATA_1               = 8'h3c,
    ADDR_U_INDEX_CTRL                 = 8'h40,
    ADDR_U_VALUE_DATA_0               = 8'h44,
    ADDR_U_VALUE_DATA_1               = 8'h48,
    ADDR_U_VALUE_CTRL                 = 8'h4c,
    ADDR_U_PIVOT_INDEX_DATA_0         = 8'h50,
    ADDR_U_PIVOT_INDEX_DATA_1         = 8'h54,
    ADDR_U_PIVOT_INDEX_CTRL           = 8'h58,
    ADDR_COLUMN_COUNT_DATA_0          = 8'h5c,
    ADDR_COLUMN_COUNT_CTRL            = 8'h60,
    ADDR_ENTRY_COUNT_DATA_0           = 8'h64,
    ADDR_ENTRY_COUNT_CTRL             = 8'h68,
    ADDR_BLOCK_PIVOT_VALUE_DATA_0     = 8'h6c,
    ADDR_BLOCK_PIVOT_VALUE_DATA_1     = 8'h70,
    ADDR_BLOCK_PIVOT_VALUE_CTRL       = 8'h74,
    ADDR_BLOCK_START_DATA_0           = 8'h78,
    ADDR_BLOCK_START_CTRL             = 8'h7c,
    ADDR_BLOCK_SIZE_DATA_0            = 8'h80,
    ADDR_BLOCK_SIZE_CTRL              = 8'h84,
    ADDR_RHS_ARRAY_DATA_0             = 8'h88,
    ADDR_RHS_ARRAY_DATA_1             = 8'h8c,
    ADDR_RHS_ARRAY_CTRL               = 8'h90,
    ADDR_RHS_INDEX_DATA_0             = 8'h94,
    ADDR_RHS_INDEX_DATA_1             = 8'h98,
    ADDR_RHS_INDEX_CTRL               = 8'h9c,
    ADDR_RHS_SIZE_DATA_0              = 8'ha0,
    ADDR_RHS_SIZE_CTRL                = 8'ha4,
    ADDR_RHS_COUNT_DATA_0             = 8'ha8,
    ADDR_RHS_COUNT_CTRL               = 8'hac,
    ADDR_RHS_COUNT_OUT_DATA_0         = 8'hb0,
    ADDR_RHS_COUNT_OUT_CTRL           = 8'hb4,
    ADDR_BLOCK_SYNTHETIC_TICKS_DATA_0 = 8'hc0,
    ADDR_BLOCK_SYNTHETIC_TICKS_CTRL   = 8'hc4,
    WRIDLE                            = 2'd0,
    WRDATA                            = 2'd1,
    WRRESP                            = 2'd2,
    WRRESET                           = 2'd3,
    RDIDLE                            = 2'd0,
    RDDATA                            = 2'd1,
    RDRESET                           = 2'd2,
    ADDR_BITS                = 8;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg                           int_ap_idle;
    reg                           int_ap_ready = 1'b0;
    wire                          task_ap_ready;
    reg                           int_ap_done = 1'b0;
    wire                          task_ap_done;
    reg                           int_task_ap_done = 1'b0;
    reg                           int_ap_start = 1'b0;
    reg                           int_interrupt = 1'b0;
    reg                           int_auto_restart = 1'b0;
    reg                           auto_restart_status = 1'b0;
    wire                          auto_restart_done;
    reg                           int_gie = 1'b0;
    reg  [1:0]                    int_ier = 2'b0;
    reg  [1:0]                    int_isr = 2'b0;
    reg  [31:0]                   int_ap_return;
    reg  [31:0]                   int_mode = 'b0;
    reg  [63:0]                   int_u_start = 'b0;
    reg  [63:0]                   int_u_end = 'b0;
    reg  [63:0]                   int_u_index = 'b0;
    reg  [63:0]                   int_u_value = 'b0;
    reg  [63:0]                   int_u_pivot_index = 'b0;
    reg  [31:0]                   int_column_count = 'b0;
    reg  [31:0]                   int_entry_count = 'b0;
    reg  [63:0]                   int_block_pivot_value = 'b0;
    reg  [31:0]                   int_block_start = 'b0;
    reg  [31:0]                   int_block_size = 'b0;
    reg  [63:0]                   int_rhs_array = 'b0;
    reg  [63:0]                   int_rhs_index = 'b0;
    reg  [31:0]                   int_rhs_size = 'b0;
    reg  [31:0]                   int_rhs_count = 'b0;
    reg                           int_rhs_count_out_ap_vld;
    reg  [31:0]                   int_rhs_count_out = 'b0;
    reg                           int_block_synthetic_ticks_ap_vld;
    reg  [31:0]                   int_block_synthetic_ticks = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= AWADDR[ADDR_BITS-1:0];
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_AP_CTRL: begin
                    rdata[0] <= int_ap_start;
                    rdata[1] <= int_task_ap_done;
                    rdata[2] <= int_ap_idle;
                    rdata[3] <= int_ap_ready;
                    rdata[7] <= int_auto_restart;
                    rdata[9] <= int_interrupt;
                end
                ADDR_GIE: begin
                    rdata <= int_gie;
                end
                ADDR_IER: begin
                    rdata <= int_ier;
                end
                ADDR_ISR: begin
                    rdata <= int_isr;
                end
                ADDR_AP_RETURN_0: begin
                    rdata <= int_ap_return[31:0];
                end
                ADDR_MODE_DATA_0: begin
                    rdata <= int_mode[31:0];
                end
                ADDR_U_START_DATA_0: begin
                    rdata <= int_u_start[31:0];
                end
                ADDR_U_START_DATA_1: begin
                    rdata <= int_u_start[63:32];
                end
                ADDR_U_END_DATA_0: begin
                    rdata <= int_u_end[31:0];
                end
                ADDR_U_END_DATA_1: begin
                    rdata <= int_u_end[63:32];
                end
                ADDR_U_INDEX_DATA_0: begin
                    rdata <= int_u_index[31:0];
                end
                ADDR_U_INDEX_DATA_1: begin
                    rdata <= int_u_index[63:32];
                end
                ADDR_U_VALUE_DATA_0: begin
                    rdata <= int_u_value[31:0];
                end
                ADDR_U_VALUE_DATA_1: begin
                    rdata <= int_u_value[63:32];
                end
                ADDR_U_PIVOT_INDEX_DATA_0: begin
                    rdata <= int_u_pivot_index[31:0];
                end
                ADDR_U_PIVOT_INDEX_DATA_1: begin
                    rdata <= int_u_pivot_index[63:32];
                end
                ADDR_COLUMN_COUNT_DATA_0: begin
                    rdata <= int_column_count[31:0];
                end
                ADDR_ENTRY_COUNT_DATA_0: begin
                    rdata <= int_entry_count[31:0];
                end
                ADDR_BLOCK_PIVOT_VALUE_DATA_0: begin
                    rdata <= int_block_pivot_value[31:0];
                end
                ADDR_BLOCK_PIVOT_VALUE_DATA_1: begin
                    rdata <= int_block_pivot_value[63:32];
                end
                ADDR_BLOCK_START_DATA_0: begin
                    rdata <= int_block_start[31:0];
                end
                ADDR_BLOCK_SIZE_DATA_0: begin
                    rdata <= int_block_size[31:0];
                end
                ADDR_RHS_ARRAY_DATA_0: begin
                    rdata <= int_rhs_array[31:0];
                end
                ADDR_RHS_ARRAY_DATA_1: begin
                    rdata <= int_rhs_array[63:32];
                end
                ADDR_RHS_INDEX_DATA_0: begin
                    rdata <= int_rhs_index[31:0];
                end
                ADDR_RHS_INDEX_DATA_1: begin
                    rdata <= int_rhs_index[63:32];
                end
                ADDR_RHS_SIZE_DATA_0: begin
                    rdata <= int_rhs_size[31:0];
                end
                ADDR_RHS_COUNT_DATA_0: begin
                    rdata <= int_rhs_count[31:0];
                end
                ADDR_RHS_COUNT_OUT_DATA_0: begin
                    rdata <= int_rhs_count_out[31:0];
                end
                ADDR_RHS_COUNT_OUT_CTRL: begin
                    rdata[0] <= int_rhs_count_out_ap_vld;
                end
                ADDR_BLOCK_SYNTHETIC_TICKS_DATA_0: begin
                    rdata <= int_block_synthetic_ticks[31:0];
                end
                ADDR_BLOCK_SYNTHETIC_TICKS_CTRL: begin
                    rdata[0] <= int_block_synthetic_ticks_ap_vld;
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign interrupt         = int_interrupt;
assign ap_start          = int_ap_start;
assign task_ap_done      = (ap_done && !auto_restart_status) || auto_restart_done;
assign task_ap_ready     = ap_ready && !int_auto_restart;
assign auto_restart_done = auto_restart_status && (ap_idle && !int_ap_idle);
assign mode              = int_mode;
assign u_start           = int_u_start;
assign u_end             = int_u_end;
assign u_index           = int_u_index;
assign u_value           = int_u_value;
assign u_pivot_index     = int_u_pivot_index;
assign column_count      = int_column_count;
assign entry_count       = int_entry_count;
assign block_pivot_value = int_block_pivot_value;
assign block_start       = int_block_start;
assign block_size        = int_block_size;
assign rhs_array         = int_rhs_array;
assign rhs_index         = int_rhs_index;
assign rhs_size          = int_rhs_size;
assign rhs_count         = int_rhs_count;
// int_interrupt
always @(posedge ACLK) begin
    if (ARESET)
        int_interrupt <= 1'b0;
    else if (ACLK_EN) begin
        if (int_gie && (|int_isr))
            int_interrupt <= 1'b1;
        else
            int_interrupt <= 1'b0;
    end
end

// int_ap_start
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_start <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0] && WDATA[0])
            int_ap_start <= 1'b1;
        else if (ap_ready)
            int_ap_start <= int_auto_restart; // clear on handshake/auto restart
    end
end

// int_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_done <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_done <= ap_done;
    end
end

// int_task_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_task_ap_done <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_done)
            int_task_ap_done <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_task_ap_done <= 1'b0; // clear on read
    end
end

// int_ap_idle
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_idle <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_idle <= ap_idle;
    end
end

// int_ap_ready
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_ready <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_ready)
            int_ap_ready <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_ap_ready <= 1'b0;
    end
end

// int_auto_restart
always @(posedge ACLK) begin
    if (ARESET)
        int_auto_restart <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0])
            int_auto_restart <=  WDATA[7];
    end
end

// auto_restart_status
always @(posedge ACLK) begin
    if (ARESET)
        auto_restart_status <= 1'b0;
    else if (ACLK_EN) begin
        if (int_auto_restart)
            auto_restart_status <= 1'b1;
        else if (ap_idle)
            auto_restart_status <= 1'b0;
    end
end

// int_gie
always @(posedge ACLK) begin
    if (ARESET)
        int_gie <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_GIE && WSTRB[0])
            int_gie <= WDATA[0];
    end
end

// int_ier
always @(posedge ACLK) begin
    if (ARESET)
        int_ier <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IER && WSTRB[0])
            int_ier <= WDATA[1:0];
    end
end

// int_isr[0]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[0] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[0] & ap_done)
            int_isr[0] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[0] <= int_isr[0] ^ WDATA[0]; // toggle on write
    end
end

// int_isr[1]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[1] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[1] & ap_ready)
            int_isr[1] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[1] <= int_isr[1] ^ WDATA[1]; // toggle on write
    end
end

// int_ap_return
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_return <= 0;
    else if (ACLK_EN) begin
        if (ap_done)
            int_ap_return <= ap_return;
    end
end

// int_mode[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_mode[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_MODE_DATA_0)
            int_mode[31:0] <= (WDATA[31:0] & wmask) | (int_mode[31:0] & ~wmask);
    end
end

// int_u_start[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_start[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_START_DATA_0)
            int_u_start[31:0] <= (WDATA[31:0] & wmask) | (int_u_start[31:0] & ~wmask);
    end
end

// int_u_start[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_start[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_START_DATA_1)
            int_u_start[63:32] <= (WDATA[31:0] & wmask) | (int_u_start[63:32] & ~wmask);
    end
end

// int_u_end[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_end[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_END_DATA_0)
            int_u_end[31:0] <= (WDATA[31:0] & wmask) | (int_u_end[31:0] & ~wmask);
    end
end

// int_u_end[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_end[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_END_DATA_1)
            int_u_end[63:32] <= (WDATA[31:0] & wmask) | (int_u_end[63:32] & ~wmask);
    end
end

// int_u_index[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_index[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_INDEX_DATA_0)
            int_u_index[31:0] <= (WDATA[31:0] & wmask) | (int_u_index[31:0] & ~wmask);
    end
end

// int_u_index[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_index[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_INDEX_DATA_1)
            int_u_index[63:32] <= (WDATA[31:0] & wmask) | (int_u_index[63:32] & ~wmask);
    end
end

// int_u_value[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_value[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_VALUE_DATA_0)
            int_u_value[31:0] <= (WDATA[31:0] & wmask) | (int_u_value[31:0] & ~wmask);
    end
end

// int_u_value[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_value[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_VALUE_DATA_1)
            int_u_value[63:32] <= (WDATA[31:0] & wmask) | (int_u_value[63:32] & ~wmask);
    end
end

// int_u_pivot_index[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_pivot_index[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_PIVOT_INDEX_DATA_0)
            int_u_pivot_index[31:0] <= (WDATA[31:0] & wmask) | (int_u_pivot_index[31:0] & ~wmask);
    end
end

// int_u_pivot_index[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_pivot_index[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_PIVOT_INDEX_DATA_1)
            int_u_pivot_index[63:32] <= (WDATA[31:0] & wmask) | (int_u_pivot_index[63:32] & ~wmask);
    end
end

// int_column_count[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_column_count[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_COLUMN_COUNT_DATA_0)
            int_column_count[31:0] <= (WDATA[31:0] & wmask) | (int_column_count[31:0] & ~wmask);
    end
end

// int_entry_count[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_entry_count[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ENTRY_COUNT_DATA_0)
            int_entry_count[31:0] <= (WDATA[31:0] & wmask) | (int_entry_count[31:0] & ~wmask);
    end
end

// int_block_pivot_value[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_block_pivot_value[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BLOCK_PIVOT_VALUE_DATA_0)
            int_block_pivot_value[31:0] <= (WDATA[31:0] & wmask) | (int_block_pivot_value[31:0] & ~wmask);
    end
end

// int_block_pivot_value[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_block_pivot_value[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BLOCK_PIVOT_VALUE_DATA_1)
            int_block_pivot_value[63:32] <= (WDATA[31:0] & wmask) | (int_block_pivot_value[63:32] & ~wmask);
    end
end

// int_block_start[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_block_start[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BLOCK_START_DATA_0)
            int_block_start[31:0] <= (WDATA[31:0] & wmask) | (int_block_start[31:0] & ~wmask);
    end
end

// int_block_size[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_block_size[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_BLOCK_SIZE_DATA_0)
            int_block_size[31:0] <= (WDATA[31:0] & wmask) | (int_block_size[31:0] & ~wmask);
    end
end

// int_rhs_array[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_array[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_ARRAY_DATA_0)
            int_rhs_array[31:0] <= (WDATA[31:0] & wmask) | (int_rhs_array[31:0] & ~wmask);
    end
end

// int_rhs_array[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_array[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_ARRAY_DATA_1)
            int_rhs_array[63:32] <= (WDATA[31:0] & wmask) | (int_rhs_array[63:32] & ~wmask);
    end
end

// int_rhs_index[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_index[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_INDEX_DATA_0)
            int_rhs_index[31:0] <= (WDATA[31:0] & wmask) | (int_rhs_index[31:0] & ~wmask);
    end
end

// int_rhs_index[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_index[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_INDEX_DATA_1)
            int_rhs_index[63:32] <= (WDATA[31:0] & wmask) | (int_rhs_index[63:32] & ~wmask);
    end
end

// int_rhs_size[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_size[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_SIZE_DATA_0)
            int_rhs_size[31:0] <= (WDATA[31:0] & wmask) | (int_rhs_size[31:0] & ~wmask);
    end
end

// int_rhs_count[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_count[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHS_COUNT_DATA_0)
            int_rhs_count[31:0] <= (WDATA[31:0] & wmask) | (int_rhs_count[31:0] & ~wmask);
    end
end

// int_rhs_count_out
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_count_out <= 0;
    else if (ACLK_EN) begin
        if (rhs_count_out_ap_vld)
            int_rhs_count_out <= rhs_count_out;
    end
end

// int_rhs_count_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_rhs_count_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (rhs_count_out_ap_vld)
            int_rhs_count_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_RHS_COUNT_OUT_CTRL)
            int_rhs_count_out_ap_vld <= 1'b0; // clear on read
    end
end

// int_block_synthetic_ticks
always @(posedge ACLK) begin
    if (ARESET)
        int_block_synthetic_ticks <= 0;
    else if (ACLK_EN) begin
        if (block_synthetic_ticks_ap_vld)
            int_block_synthetic_ticks <= block_synthetic_ticks;
    end
end

// int_block_synthetic_ticks_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_block_synthetic_ticks_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (block_synthetic_ticks_ap_vld)
            int_block_synthetic_ticks_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_BLOCK_SYNTHETIC_TICKS_CTRL)
            int_block_synthetic_ticks_ap_vld <= 1'b0; // clear on read
    end
end

//synthesis translate_off
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (int_gie & ~int_isr[0] & int_ier[0] & ap_done)
            $display ("// Interrupt Monitor : interrupt for ap_done detected @ \"%0t\"", $time);
        if (int_gie & ~int_isr[1] & int_ier[1] & ap_ready)
            $display ("// Interrupt Monitor : interrupt for ap_ready detected @ \"%0t\"", $time);
    end
end
//synthesis translate_on

//------------------------Memory logic-------------------

endmodule
